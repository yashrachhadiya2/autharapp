class ModalData{

String? AutharName,About,Book,Ratings,Year,image;

ModalData({this.AutharName, this.About, this.Book, this.Ratings, this.Year,this.image});
}