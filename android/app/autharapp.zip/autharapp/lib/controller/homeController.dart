import 'package:get/get.dart';

class HomeController extends GetxController{
  RxList userlist = [].obs;
}